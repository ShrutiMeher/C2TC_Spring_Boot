package com.example.mall;

import org.springframework.data.jpa.repository.JpaRepository;

public interface MallRepository  extends JpaRepository<Mall, Integer> 
{

}